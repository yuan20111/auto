#!/bin/bash

#NOTE, RUNing dir
#loglevel=0, 1, 2, 3

NOTE=/home/zhiyuan/gitlab-related/gitlab-related-1.0/note/compile.txt            #note地址
loglevel=1
DIR=/home/zhiyuan/gitlab-related/gitlab-related-1.0/src/git-runing               #运行目录
DESTDIR=~/nfs-deb                                             #产出物

#from loglevel debug log
debug(){
	#if [ ! -n $@ ]; then  #yuan加参数存在
	#		return
	#fi
	case $loglevel in 
		0)
			;;
		1)
			[[ $1 ]] && echo ">>> $*"          #输出到终端
			;;
		2)
			[[ $1 ]] && echo ">>> $*"
			[[ $1 ]] && echo ">>> $*" >> /tmp/gitlab-related.log     #保存日志
			;;
		*)
			[[ $1 ]] && echo ">>> loglevel error"
			[[ $1 ]] && echo ">>> loglevel error" >> /tmp/gitlab-related.log
			exit 3
			;;
	esac
}

#保持文本格式,空格 tab不变
IFS=""

get_note(){
	debug "开始获取note信息"

	if [ ! -f $NOTE ]; then  #判断变量未定义
		echo "note文件不存在"
		exit 4
	fi
	local notehead=`cat $NOTE | head -1`
	gitip=`echo "$notehead" | awk '{print $2}'`
	branch=`echo "$notehead" | awk '{print $3}'`
	proj=`echo ${gitip##*/} | awk -F . '{print $1}'` 
	debug "notehead: $notehead"
	debug "gitip   : $gitip"
	debug "branch  : $branch"
	debug "project : $proj"
}

config(){   #yuan检查目录,按分子分类
	:
	if [ "$dir" != "/home/nfs/xqguo"  -a "$dir" != "/home/nfs/xuequan" ];then
		echo "当前路径不正确，将要退出"
		exit
	fi 
}       

get_src(){
	#检查proj是否已经存在/ 检查$proj === $src_name
	cd $DIR
	debug "开始克隆代码"
	if [ -d $proj ]; then
		debug "rmoveing has exist $proj..."
	#yuan	rm $proj -rf
	fi
	git clone $gitip
	if [ $? -ne 0 ];then
		echo "请检查克隆地址"
	#yuan	exit 2
	fi
}

copy_deb(){
	debug "copying deb"
	#日志信息。包信息
	local dpkgnote=$DESTDIR/$proj/dpkg-note.txt
	grep -v "编译参数" $NOTE > $dpkgnote
	echo "生成 Deb :" >> $dpkgnote

	local flag=0
	local deb_num=`find $DIR/$proj -print | grep deb$ | wc -l`
	for deb in $DIR/$proj/*deb; do
		cp $deb $DESTDIR/$proj && let flag+=1
		echo "    ${deb##*/}" >> $dpkgnote
		[ "$?" -ne "0" ] && debug "copy error!" && exit 3
	done
	[ "$flag" == "$deb_num" ]  && debug "copy success!!"

}


build(){
	debug "开始生成deb包，copy包和note到指定位置"
	path=`find $DIR/$proj -print | grep debian/changelog$ |sed -n 1p`
	path=${path:0:0-17}
	debug "$path  --------"

	cd $path
	git branch
	git checkout $branch
	if [ $? -ne 0 ];then
		echo "切换分支失败"
		exit 3
	fi  
	
	local src_control=`find $path -print | grep 'debian/control$'`
	local src_name=`grep Source $src_control | awk '{print $2}'`
	debug "src name : $src_name"
#	sudo apt-get build-dep $src_name

#	dpkg-buildpackage                                    
	if [ $? -eq 0 ];then
		debug "打包成功"
		copy_deb
	else 
		debug "打包失败" && exit 3
	fi  
}

clean(){
	ls $DIR
#	find $DIR
}

main(){
	debug "开始编译和预编译"
	get_note 
	[ ! -d "$DESTDIR/$proj" ] && mkdir -p "$DESTDIR/$proj"  #创建对应的产物目录地址
	get_src 
	build
	clean
	debug "完成编译和预编译"
}

main 
