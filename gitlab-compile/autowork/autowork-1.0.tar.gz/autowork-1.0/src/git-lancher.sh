#!/bin/bash

NOTE=/home/zhiyuan/gitlab-related/gitlab-related-1.0/note/compile.txt

while [ 1 ];do
	
	if [ -e $NOTE ]; then
		echo "存在"  && exit 3
	fi
	
done













